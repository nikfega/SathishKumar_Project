package utilities;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;

import resource.Properties;

public class DriverFactory {
	public static WebDriver driver=null;
	
	public static WebDriver initiateBrowser(String browserName) throws Exception{
		
		if(browserName.equalsIgnoreCase("IE")||browserName.equalsIgnoreCase("InternetExplorer")||browserName.equalsIgnoreCase("Internet Explorer")){
			System.setProperty("webdriver.ie.driver",Properties.ieDriverPath);
			driver=new InternetExplorerDriver();
			driver.manage().window().maximize();
			driver.manage().deleteAllCookies();
			setTimeouts();
		}
		else if(browserName.equalsIgnoreCase("Chrome")||browserName.equalsIgnoreCase("GoogleChrome")||browserName.equalsIgnoreCase("Google Chrome")){
			System.setProperty("webdriver.ie.driver",Properties.chromeDriverPath);
			driver=new InternetExplorerDriver();
			driver.manage().window().maximize();
			driver.manage().deleteAllCookies();
			setTimeouts();
		}
		else
			throw new Exception("Kindly mention the valid Browser Name");
		return driver;
	}
	
	private static void setTimeouts(){
		driver.manage().timeouts().implicitlyWait(Properties.implicitWait, TimeUnit.SECONDS);
		driver.manage().timeouts().setScriptTimeout(Properties.scriptTimeout, TimeUnit.SECONDS);
		driver.manage().timeouts().pageLoadTimeout(Properties.pageLoadTimeout, TimeUnit.SECONDS);
	}

}
