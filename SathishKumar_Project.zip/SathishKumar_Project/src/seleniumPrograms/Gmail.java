package seleniumPrograms;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import resource.Properties;
import utilities.DriverFactory;
import utilities.SeleniumUtils;

public class Gmail extends DriverFactory {

	public static By loginId = By.xpath("//input[@type='email']");
	public static By password = By.xpath("//input[@type='password']");
	public static By nextBtn = By.xpath("//span[contains(text(),'Next')]");
	public static By userNameErrorMsg = By.xpath("//div[contains(text(),'Enter an email or phone number')]");
	public static By passwordErrorMsg = By.xpath("//div[contains(text(),'Enter a password')]");
	public static By inbox=By.xpath("//a[contains(text(),'Inbox')]");

	@BeforeMethod
	public static void before() throws Exception {
		initiateBrowser(Properties.browserName);
		System.out.println("init");
		driver.get("https://www.google.com/gmail/");
	}

	@Test
	public static void test() throws Exception {
		String errorMsg = "";

		driver.findElement(loginId).sendKeys("sathishkumar2992@gmail.com");
		driver.findElement(nextBtn).click();
		SeleniumUtils.waitForElement(password);
		driver.findElement(password).sendKeys("1232");
		driver.findElement(nextBtn).click();
		String actualErrorMsg = "";
		WebElement error = driver.findElement(passwordErrorMsg);
		actualErrorMsg = error.getText();
		Assert.assertNotEquals(errorMsg, actualErrorMsg, "Test Case failed due to False Assertion");
		System.out.println("Login failed");
	}

	@Test() // Null password
	public static void nullPasswordCase() throws Exception {
		String errorMsg = "";
		driver.findElement(loginId).sendKeys("sathishkumar2992@gmail.com");
		driver.findElement(nextBtn).click();
		Thread.sleep(5000);
		driver.findElement(password).sendKeys("   ");
		driver.findElement(nextBtn).click();
		String actualErrorMsg = "";
		WebElement error = driver.findElement(passwordErrorMsg);
		actualErrorMsg = error.getText();
		Assert.assertNotEquals(errorMsg, actualErrorMsg, "Test Case failed due to False Assertion");
	}

	@Test()
	public static void nullUserName() throws Exception {
		String errorMsg = "";
		driver.findElement(loginId).sendKeys("sathishkumar2992@gmail.com");
		driver.findElement(nextBtn).click();
		Thread.sleep(5000);
		driver.findElement(nextBtn).click();
		WebElement Error = driver.findElement(userNameErrorMsg);
		String actualErrorMsg = "";
		if (Error.isDisplayed())
			;
		actualErrorMsg = Error.getText();
		Assert.assertNotEquals(errorMsg, actualErrorMsg, "Test Case failed due to False Assertion");

	}

	// Positive scenario- Please provide your valid email id and password
	@Test
	public static void positiveScenario() throws Exception {
		driver.findElement(loginId).sendKeys("sathishkumar2992@gmail.com");
		driver.findElement(nextBtn).click();
		SeleniumUtils.waitForElement(password);
		driver.findElement(password).sendKeys("validPassword");
		driver.findElement(nextBtn).click();
		Assert.assertEquals("Inbox",driver.findElement(inbox).getText());
		System.out.println("Login success");
	}
}