package seleniumPrograms;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class ClearTrip {
	public static String hotels="Hotels";
	public static String where="//input[@title='Where do you want to go']";
	public static String checkin="(//input[@title='Check-in date']/following::i[@class='calendarIcon datePicker'])[1]";
	public static String checkout="(//input[@title='Check-out date']/following::i[@class='calendarIcon datePicker'])[1]";
	public static String searchButton="//*[@id='SearchHotelsButton']";

	public Properties properties;
	public static WebDriver driver = null;

	public WebDriver iniateDriver() throws FileNotFoundException, IOException {
		properties = new Properties();
		properties.load(new FileInputStream(new File("./src/repository/Config.properties")));
		System.setProperty("webdriver.chrome.driver", properties.getProperty("chromedriver"));
		if (driver == null)
			driver = new ChromeDriver();
		return driver;

	}
	 
	public void launchBrowser() {
		driver.get(properties.getProperty("URL"));
	}
	public void searchOption(String option) {
		launchBrowser();
		driver.findElement(By.linkText(option)).click();
	}
	public void searchHotel(String place) {
		driver.findElement(By.xpath(where)).sendKeys(place);
	}
	
	public void checkIncheckOut(String checkinDate,String checkoutDate) {
		String fromDate[]=checkinDate.split(("/"));
		String fromdateValue=fromDate[0];
		String fromMonthValue=fromDate[1];
		String fromYearValue=fromDate[2];
		
		driver.findElement(By.xpath((checkin))).click();
		System.out.println(fromdateValue+"/"+fromMonthValue+"/"+fromYearValue);
		
		String dateFromSelect="//a[contains(text(),'"+fromdateValue+"')]/parent::td[@data-month='"+fromMonthValue+"' and @data-year='"+fromYearValue+"']";
		driver.findElement(By.xpath(dateFromSelect)).click();
		
		String toDate[]=checkoutDate.split(("/"));
		String todateValue=toDate[0];
		String toMonthValue=toDate[1];
		String toYearValue=toDate[2];
		
		driver.findElement(By.xpath((checkout))).click();
		System.out.println(fromdateValue+"/"+fromMonthValue+"/"+fromYearValue);
		
		String dateToSelect="//a[contains(text(),'"+todateValue+"')]/parent::td[@data-month='"+toMonthValue+"' and @data-year='"+toYearValue+"']";
		driver.findElement(By.xpath(dateToSelect)).click();
		
		driver.findElement(By.xpath(searchButton)).click();

	}
	
public static void main(String[] args) throws FileNotFoundException, IOException {
		
		ClearTrip obj=new ClearTrip();
		obj.iniateDriver();
		obj.searchOption("Hotels");
		obj.searchHotel("Chennai");
		obj.checkIncheckOut("17/2/2019","18/2/2019");
	}
	
}

