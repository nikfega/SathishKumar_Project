package javaPrograms;

public class StringReverse {

	public static void reverseString(String inputString) {
		char[] charvalues = inputString.toCharArray();
		for (int count = charvalues.length - 1; count >= 0; count--)
			System.out.print(inputString.charAt(count));
	}

	public static void main(String[] args) {

		String inputString = "I am good";
		reverseString(inputString);
	}

}
