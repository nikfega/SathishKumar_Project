package javaPrograms;

public class CharacterOccuranceInString {
	
	public void characterOccurance(String inputOccurString){
		
		System.out.println("Input String--> "+inputOccurString);
		
		char countchar[] = new char[inputOccurString.length()];
		
		int count[]=new int[250];
		
		for(int c=0;c<inputOccurString.length();c++)
			count[inputOccurString.charAt(c)]++;

		for (int outerCount = 0; outerCount < inputOccurString.length(); outerCount++) {
			countchar[outerCount] = inputOccurString.charAt(outerCount);
			int match = 0;
			for (int innerCount = 0; innerCount <= outerCount; innerCount++) {
				if (inputOccurString.charAt(innerCount) == countchar[outerCount]) {
					match++;
				}
			}
			if(match==1)
				System.out.println("Occurence of " + countchar[outerCount] + "	is " + count[inputOccurString.charAt(outerCount)]);
		}
		
	}

	
	public static void main(String[] args) {
		
		CharacterOccuranceInString obj = new CharacterOccuranceInString();
		obj.characterOccurance("haithissriarmw");
		
	}
}
