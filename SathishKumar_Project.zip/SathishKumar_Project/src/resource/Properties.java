package resource;

public class Properties {
	
	public static int implicitWait=30;
	public static int pageLoadTimeout=120;
	public static int scriptTimeout=30;
	public static String ieDriverPath="Drivers/IEDriverServer.exe";
	public static String chromeDriverPath=".//drivers//chromedriver.exe";
	public static String browserName="Chrome";
	
}
